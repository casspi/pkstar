const aaa = require('@pkstar/utils')
console.log('module=>', aaa)

import { a2o } from '@pkstar/utils'
console.log('import=>', a2o)
